<?php

include_once "model.php";

class Customers extends Model {
    protected $tableName = 'customers';
    public function insert($name,$birth,$cpf,$phone,$email){
        $this->connection->query("
        INSERT INTO $this->tableName
        (name, cpf,birth ,phone, email)
        values('$name', '$cpf','$birth', '$phone', '$email')");
    }

    public function delete($id){
        $this->connection->query("DELETE FROM customers WHERE id=$id");
    }

    public function update ($id, $name,$cpf,$birth,$phone,$email){
        $result= $this->connection->prepare
        ("UPDATE customers SET name=?, cpf=?, birth = ?, phone=?, email=? WHERE id=?");
        $result->bind_param("sssssi", $name, $cpf, $birth, $phone, $email, $id);
        $result->execute();
        $result->close();
    }
}
