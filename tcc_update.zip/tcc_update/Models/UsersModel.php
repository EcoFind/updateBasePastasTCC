<?php

require "Models/model.php";

class UsersModel extends Model {

    public function canLogin($email, $password){

        $password = md5($password);
        
        $result = $this->connection->query("SELECT * FROM users WHERE email = '$email' and password = '$password' ");

        $user = $result->fetch_all(MYSQLI_ASSOC); //array de resultado

        if($user[0]){
            return $user[0];
        }else{
            return false;
        }
    }

    public function register($username, $email, $password){

        if($this->userExist($email)){
            return false;
        }
 
        $password = md5($password);
 
        $result = $this->connection->query("INSERT INTO users (username, email, password) values ('$username', '$email', '$password')");
 
        return $result; //1 ou 0
    }

    public function userExist($email){
        //retorna true se o usuario existir no banco de dados

        $result = $this->connection->query("SELECT * FROM users WHERE email = '$email' ");
 
        $user = $result->fetch_all(MYSQLI_ASSOC);
  
        return isset($user[0]);
    }
}