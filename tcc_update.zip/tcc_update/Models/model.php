<?php 

require "conexao.php";

class Model extends database {

        protected $tableName;

        public function select(){
            $result = $this->connection->query("SELECT * FROM $this->tableName");

            return $result->fetch_all(MYSQLI_ASSOC);
        }

}