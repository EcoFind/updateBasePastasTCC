<?php

require "Views/Admin/AdminView.php";

class ClientesController {

    public function main(){

        $action = $_GET['acao'] ?? null;

        switch ($action) {
            case 'adicionar':
                $this->form();
                break;

            case 'edit':
                $this->edit();
                break;

            case 'savedit':
                $this->saveEdit();
                break;

            case 'salvar':
                $this->save();
                break;

            case 'delete':
                $this->delete();
                break;

            default:
            $this->index();
                break;
        }
    }

    public function save(){
        $name = $_POST['name'];
        $cpf = $_POST['cpf'];
        $nasc = $_POST['birth'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];

        include_once "Models/CustomersModel.php";
        $model = new Customers();

        $model->insert($name,$cpf,$nasc,$phone,$email);

        $this->index();
    }

    private function index(){
        include_once "Models/CustomersModel.php";

        $tableName = 'customers';

        $model = new Customers();
        $customers = $model->select($tableName);

        view("views/admin/clientes/indexClientView.phtml",$customers);
    }

    private function delete(){
        include_once "Models/CustomersModel.php";

        $tableName = 'customers';

        $model = new Customers();
        $customers = $model->delete($_GET['id']);

        $this->index();
    }

    private function form(){
        view("Views/Admin/Clientes/FormClienteView.phtml");
    }

    private function edit(){
        include_once "Models/CustomersModel.php";

        $tableName = 'customers';

        $model = new Customers();
        $customers = $model->select($tableName);

        $data;

        foreach($customers as $cliente){
            if($cliente['id'] == $_GET['id']){
                $data = $cliente;
                break;
            }
        }

        view("Views/Admin/Clientes/FormClienteEditView.phtml",$data);
    }

    private function saveEdit(){
        $name = $_POST['name'];
        $cpf = $_POST['cpf'];
        $nasc = $_POST['birth'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];

        include_once "Models/CustomersModel.php";
        $model = new Customers();

        $model->update($_GET['id'],$name,$cpf,$nasc,$phone,$email);

        $this->index();
    }
}