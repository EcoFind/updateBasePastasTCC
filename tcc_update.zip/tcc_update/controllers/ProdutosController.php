<?php

require "Views/Admin/AdminView.php";

class ProdutoController {

    public function main(){

        $action = $_GET['acao'] ?? null;

        switch ($action) {
            default:
                $this->index();
                break;
        }
    }

    private function index(){
        view("Views/Admin/Produtos/IndexProdutoView.phtml");
    }
}