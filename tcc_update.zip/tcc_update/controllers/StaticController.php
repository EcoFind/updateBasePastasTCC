<?php

    class StaticController {

        public function main() {

            $action = $_GET['acao'] ?? null;

            switch($action){

                case 'entrar':
                   $this->login();
                    break;
                case 'registrar':
                    $this->register();
                    break;
                
                default:
                    $this->Seeanimals();
                    break;
                    
            }

        }

        public function login() {
            if(isset($_POST['email'])){
                $email = $_POST['email']?? null;
                $password = $_POST['password'] ?? null;

                if($email && $password){    
                    
                    require_once 'Models/UsersModel.php';


                    $Model = new UsersModel();

                    $usuario = $Model->CanLogin($email , $password);

                    if($usuario['username']){
                        session_start();
                        $_SESSION['usuario']= $usuario;
                        header('Location: /?pagina=admin');
                    }else{
                        require 'Views/static/Loginpageview.html';
                    }
                }
            }else{
                echo 'falha ,email ou sennha incorretos';
                
                require 'Views/static/Loginpageview.html';

            }
        }

        
        public function register(){
            if(isset($_POST['email'])){
                $email = $_POST['email'] ?? null;
                $username = $_POST['username'] ?? null;
                $password = $_POST['password'] ?? null;
    
                if($email && $username && $password){
                    require_once 'Models/UsersModel.php';
    
                    $Model = new UsersModel();

                    $result = $Model->register($username, $email, $password);
    
                    if($result){
                        
                    $this->login();
                    }else{
                        echo "email já cadastrado!";
                    }
                }
            } else {
                require 'Views/Static/Registerpageview.html';
            }
    
        }

        
        public function home() {
            require 'views/static/Homepageview.html';
        }
        public function Seeanimals(){
            require 'views/static/Seeanimalspageview.html';
        }
    }
