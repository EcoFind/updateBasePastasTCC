<?php

class StaticControllers {

    public function main(){

        $action = $_GET['acao'] ?? null;


        switch ($action) {
            case 'entrar':
                $this->login();
                break;

           case 'registrar':
                $this->registre();
                break;  
           
            default:
                $this->home();
                break;
        }

    }

    public function login(){
        require 'View/Static/LoginPageview.html';
    }

    public function registre(){
        require 'Views/Static/RegisterPage.html';
    }

    public function home(){
        require 'View/Static/HomePageView.html';
    }
    

}

