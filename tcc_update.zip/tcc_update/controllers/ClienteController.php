<?php

require "Views/Admin/AdminView.php";

class ClienteController {

    public function main(){

        $action = $_GET['acao'] ?? null;

        switch ($action) {
            case 'adicionar':
                $this->form();
                break;

            case 'salvar':
                $this->save();
                break;

            default:
                $this->index();
                break;
        }
    }

    public function save(){
        $name = $_POST['name'];
        $cpf = $_POST['cpf'];
        $nasc = $_POST['birth'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];

        include_once "Models/CustomersModel.php";
        $model = new Customers();

        $model->insert($name,$cpf,$nasc,$phone,$email);

        $this->index();
    }

    private function index(){
        include_once "Models/CustomersModel.php";

        $model = new Customers();
        $customers = $model->select();

        view("Views/Admin/Clientes/IndexClienteView.phtml",$customers);
    }

    private function form(){
        view("Views/Admin/Clientes/FormClienteView.phtml");
    }
}