<?php

    function view($page ,$data = []){
        require "views/admin/Layouts/app.php";  
    }