<?php

    function view($page, $data = []){
        require "Layouts/app.php";  
    }