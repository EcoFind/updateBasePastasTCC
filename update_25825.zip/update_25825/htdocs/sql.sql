create database bd_tcc;


use bd_tcc;

create table users(
    id integer auto_increment primary key,
    username varchar(64),
    email varchar(128),
    password varchar(258)
);

create table customers(
    id integer auto_increment primary key,
    name varchar(256),
    cpf varchar(14),
    birth varchar(10),
    email varchar(128),
    phone varchar(14)
);

create table ingresso(
    id integer auto_increment primary key,
    name varchar(50),
    tutor varchar(50),
    race varchar(20),
    birth date,
    photo varchar(120)
);


create table orders(
    id integer auto_increment primary key,
    customer_id integer,
    ingresso_id integer,
    foreign key (customer_id) references customers(id),
    foreign key (ingresso_id) references ingresso(id)
);

//*
        create table usernivel(
                id integer auto_increment primary key,
                user_id integer,
                nivel varchar(10),
                foreign key (user_id) references users(id)
        );
*//


