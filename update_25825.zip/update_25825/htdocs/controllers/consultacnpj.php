<?php

public function consultarCNPJ() {
    if(isset($_GET['cnpj'])){
        $cnpj = preg_replace('/\D/', '', $_GET['cnpj']); // Remove caracteres não numéricos
        
        // Aqui você chamaria a API real de consulta ou consulta interna
        // Exemplo simplificado usando cURL para uma API fictícia
        $url = "https://receitaws.com.br/v1/cnpj/$cnpj";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        $response = curl_exec($ch);
        curl_close($ch);

        header('Content-Type: application/json');
        echo $response;
    } else {
        echo json_encode(['erro' => 'CNPJ não fornecido']);
    }
    exit;
}
