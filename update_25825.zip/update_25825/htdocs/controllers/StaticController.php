<?php

    class StaticController {

        public function main() {

            $action = $_GET['acao'] ?? null;

            switch($action){

                case 'entrar':
                   $this->login();
                    break;
                case 'registrar':
                    $this->register();
                    break;
               
                
                default:
                    $this->Dashboard();
                    break;
                    
            }

        }

        public function login() {
            if(isset($_POST['email'])){
                $email = $_POST['email']?? null;
                $password = $_POST['password'] ?? null;

                if($email && $password){    
                    
                    require_once 'Models/UsersModel.php';


                    $Model = new UsersModel();

                    $usuario = $Model->CanLogin($email , $password);

                    if($usuario['username']){
                        session_start();
                        $_SESSION['usuario']= $usuario;
                        header('Location: /?pagina=admin');
                    }else{
                        require 'Views/static/Loginpageview.html';
                    }
                }
            }else{
                echo 'falha ,email ou sennha incorretos';
                
                require 'Views/static/Loginpageview.html';

            }
        }

       


        /*
        public function register(){

            if(isset($_POST['email'])){
                $email = $_POST['email'] ?? null;
                $username = $_POST['username'] ?? null;
                $password = $_POST['password'] ?? null;
    
                if($email && $username && $password){
                    require_once 'Models/UsersModel.php';
    
                    $Model = new UsersModel();

                    $result = $Model->register($username, $email, $password);
    
                    if($result){
                        
                    $this->login();
                    }else{
                        echo "<script>alert('Email já cadastrado!, faça login');</script>";
                        require 'Views/Static/Loginpageview.html';
                    }
                }
            } else {
                require 'Views/Static/Registerpageview.html';
            }
    
        }
        */


        public function register() {

    if(isset($_POST['email'])){
        $email = $_POST['email'] ?? null;
        $username = $_POST['username'] ?? null;
        $password = $_POST['password'] ?? null;
        $cnpj = preg_replace('/\D/', '', $_POST['cnpj'] ?? null); // Remove caracteres não numéricos

        if($email && $username && $password && $cnpj){

            // Consulta o CNPJ antes de registrar
            $url = "https://receitaws.com.br/v1/cnpj/$cnpj";

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            $response = curl_exec($ch);
            curl_close($ch);

            $data = json_decode($response, true);

            if(isset($data['erro'])){
                echo "<script>alert('CNPJ inválido ou não encontrado');</script>";
                require 'Views/Static/Registerpageview.html';
                return;
            }

            require_once 'Models/UsersModel.php';
            $Model = new UsersModel();

            // Passa o CNPJ para o modelo também
            $result = $Model->register($username, $email, $password, $cnpj);

            if($result){
                $this->login();
            } else {
                echo "<script>alert('Email já cadastrado!, faça login');</script>";
                require 'Views/Static/Loginpageview.html';
            }
        } else {
            echo "<script>alert('Preencha todos os campos');</script>";
            require 'Views/Static/Registerpageview.html';
        }

    } else {
        require 'Views/Static/Registerpageview.html';
    }

}

       

        
        public function home() {
            require 'views/static/Homepageview.html';
        }
        public function Dashboard(){
            require 'views/static/Dashboardpageview.html';
        }
    }
