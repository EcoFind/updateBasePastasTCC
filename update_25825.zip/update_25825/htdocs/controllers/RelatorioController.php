<?php

require "views/admin/adminView.php";

class RelatorioController {

    public function main(){

        $action = $_GET['acao'] ?? null;

        switch ($action) {
            default:
                $this->index();
                break;
        }
    }

    private function index(){
        view("views/admin/Relatorio/IndexRelatorioView.phtml");
    }
}